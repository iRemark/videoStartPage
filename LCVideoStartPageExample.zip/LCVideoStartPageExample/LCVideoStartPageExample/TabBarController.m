//
//  TabBarController.m
//  LCVideoStartPageExample
//
//  Created by lc-macbook pro on 2017/6/8.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "TabBarController.h"

#import "ViewController1.h"
#import "ViewController2.h"

#define CONTROLLER @"rootVCClass"
#define TITLE @"titleName"
#define kImageKey @"imageName"

#define kSelectedImageKey @"selectedImage"

@interface TabBarController ()

@end

@implementation TabBarController


static TabBarController *rootVC;

+ (TabBarController *)getRootVC {
    return rootVC;
}

- (instancetype)init {
    if (self == [super init]) {
        rootVC = self;
    }
    return self;
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleDefault;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //隐藏tabbar顶部的下划线
    [self.tabBar setValue:@(YES) forKeyPath:@"_hidesShadow"];
    
    NSArray *childArray = @[
                            @{CONTROLLER : @"ViewController1",
                              TITLE : @"controller1"},
                            
                            @{CONTROLLER : @"ViewController2",
                              TITLE : @"controller2"}
                            ];
    
    [childArray enumerateObjectsUsingBlock:^(NSDictionary *object, NSUInteger idx, BOOL * _Nonnull stop) {
        
        UIViewController *vc = [[NSClassFromString(object[CONTROLLER]) alloc] init];
        vc.title = object[TITLE];
        
        UINavigationController *nvc = [[UINavigationController alloc] initWithRootViewController:vc];
        
        UITabBarItem *barItem = [[UITabBarItem alloc] initWithTitle: object[TITLE] image: nil tag:idx];
        [barItem setTitleTextAttributes:@{NSForegroundColorAttributeName :[UIColor redColor]}
                               forState:UIControlStateSelected];
        nvc.tabBarItem = barItem;
        
        [self addChildViewController:nvc];
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
