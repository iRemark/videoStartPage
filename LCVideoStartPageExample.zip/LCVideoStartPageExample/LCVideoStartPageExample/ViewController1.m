//
//  ViewController.m
//  iOS_Samples
//
//  Created by nd nd on 13-4-2.
//  Copyright (c) 2013年 Banana. All rights reserved.
//

#import "ViewController1.h"
#import "AppDelegate.h"

#import <MediaPlayer/MediaPlayer.h>
#import "AnimationVideoViewController.h"

#define SCREEN_WIDTH  [[UIScreen mainScreen]bounds].size.width
#define SCREEN_HEIGHT [[UIScreen mainScreen]bounds].size.height

@interface ViewController1 ()
@property (nonatomic,strong) AnimationVideoViewController *animationVC;

@end

@implementation ViewController1


- (void)viewDidLoad
{
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self configureVideoStrat];
}

- (void)configureVideoStrat {
    
    NSString *firstlaunch = @"firstlaunch";
    
    __weak typeof(self)weakSelf = self;
    NSInteger firstIN = [[[NSUserDefaults standardUserDefaults] valueForKey:firstlaunch] integerValue];
    if (firstIN != 0) {
        //return;
    }
    
    self.animationVC = [[AnimationVideoViewController alloc] init];
    self.animationVC.videoURL = [NSURL fileURLWithPath:[[NSBundle mainBundle]pathForResource:@"intro"ofType:@"mp4"]];
    self.animationVC.view.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    
    self.animationVC.finishBlock = ^{
        [UIView animateWithDuration:1.0 animations:^{
            weakSelf.animationVC.view.alpha = 0;
        } completion:^(BOOL finished) {
            [weakSelf.animationVC.view removeFromSuperview];
            weakSelf.animationVC = nil;
        }];
        
    };
    [[[UIApplication sharedApplication] keyWindow] addSubview:self.animationVC.view];
    [[[UIApplication sharedApplication] keyWindow] bringSubviewToFront:self.animationVC.view];
    
    [[NSUserDefaults standardUserDefaults] setValue:@(1) forKey:firstlaunch];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

@end




