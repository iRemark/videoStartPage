//
//  ViewController2.h
//  LCVideoStartPageExample
//
//  Created by lc-macbook pro on 2017/6/8.
//  Copyright © 2017年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController2 : UIViewController

@end
