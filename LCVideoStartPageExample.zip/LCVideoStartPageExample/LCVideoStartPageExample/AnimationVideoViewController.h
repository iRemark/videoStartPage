//
//  AnimationVideoViewController.h
//  MKJWechat
//
//  Created by MKJING on 16/11/30.
//  Copyright © 2016年 MKJING. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnimationVideoViewController : UIViewController

@property (nonatomic, copy) void (^finishBlock)(void);

@property (nonatomic, strong) NSURL *videoURL;

@end
